#parse("HeaderPkg.kt")
#set( $P_CAMERA = $Add_Camera_Permission )
#set( $P_NOTIFICATIONS = $Add_Notifications_Permission )
#set( $P_MICROPHONE = $Add_Microphone_Permission )
#set( $P_PHONE = $Add_Phone_Permission )
#set( $P_LOCATION = $Add_Location_Permission )
#set( $P_STORAGE = $Add_Storage_Permission )
#set( $P_CONTACTS = $Add_Contacts_Permission )
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultCaller
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import #parse("RootPkg.kt").R
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class PermissionManager private constructor(
    private val caller: ActivityResultCaller,
    private val contextProvider: () -> Context,
    private val rationaleChecker: (String) -> Boolean
) {

    private lateinit var currentPermission: AppPermission

    private var onGranted: (() -> Unit)? = null
    private var onDenied: (() -> Unit)? = null
    private var onPermanentlyDenied: (() -> Unit)? = null

    private val singleLauncher =
        caller.registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            handleSingleResult(granted)
        }

    private val multiLauncher =
        caller.registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            handleMultiResult(result)
        }

    val context: Context
        get() = contextProvider()

    companion object {

        fun from(activity: ComponentActivity): PermissionManager {
            return PermissionManager(
                caller = activity,
                contextProvider = { activity },
                rationaleChecker = { perm ->
                    ActivityCompat.shouldShowRequestPermissionRationale(activity, perm)
                }
            )
        }

        fun from(fragment: Fragment): PermissionManager {
            return PermissionManager(
                caller = fragment,
                contextProvider = { fragment.requireContext() },
                rationaleChecker = { perm ->
                    fragment.shouldShowRequestPermissionRationale(perm)
                }
            )
        }
    }

    fun request(
        permission: AppPermission,
        onGranted: () -> Unit,
        onDenied: () -> Unit,
        onPermanentlyDenied: () -> Unit
    ) {
        this.currentPermission = permission
        this.onGranted = onGranted
        this.onDenied = onDenied
        this.onPermanentlyDenied = onPermanentlyDenied

        when (permission) {
            is SinglePermission -> requestSinglePermission(permission)
            is MultiPermission -> requestMultiPermission(permission)
        }
    }


    private fun requestSinglePermission(singlePerm: SinglePermission) {
        val perm = singlePerm.permission

        when {
            hasPermission(perm) -> onGranted?.invoke()
            shouldShowRationale(perm) -> showRationaleDialog(singlePerm)
            else -> singleLauncher.launch(perm)
        }
    }

    private fun handleSingleResult(granted: Boolean) {
        val perm = (currentPermission as SinglePermission).permission

        when {
            granted -> onGranted?.invoke()
            !shouldShowRationale(perm) -> onPermanentlyDenied?.invoke()
            else -> onDenied?.invoke()
        }
    }


    private fun requestMultiPermission(multiPerm: MultiPermission) {
        val perms = multiPerm.permissions

        when {
            perms.all { hasPermission(it) } -> onGranted?.invoke()
            perms.any { shouldShowRationale(it) } -> showRationaleDialog(multiPerm)
            else -> multiLauncher.launch(perms)
        }
    }

    private fun handleMultiResult(result: Map<String, Boolean>) {
        val denied = result.filterValues { !it }.keys

        when {
            denied.isEmpty() -> onGranted?.invoke()
            denied.any { !shouldShowRationale(it) } -> onPermanentlyDenied?.invoke()
            else -> onDenied?.invoke()
        }
    }

    private fun showRationaleDialog(permission: AppPermission) {
        MaterialAlertDialogBuilder(context)
            .setTitle(permission.rationaleTitle)
            .setMessage(permission.rationaleMessage)
            .setPositiveButton(R.string.action_continue) { _, _ ->
                when (permission) {
                    is SinglePermission -> singleLauncher.launch(permission.permission)
                    is MultiPermission -> multiLauncher.launch(permission.permissions)
                }
            }
            .setNegativeButton(R.string.action_cancel) { _, _ ->
                onDenied?.invoke()
            }
            .show()
    }

    private fun hasPermission(permission: String) =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    private fun shouldShowRationale(permission: String): Boolean =
        rationaleChecker(permission)
}