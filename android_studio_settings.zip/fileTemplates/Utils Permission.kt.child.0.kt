#parse("HeaderPkg.kt")
#set( $P_CAMERA = $Add_Camera_Permission )
#set( $P_NOTIFICATIONS = $Add_Notifications_Permission )
#set( $P_MICROPHONE = $Add_Microphone_Permission )
#set( $P_PHONE = $Add_Phone_Permission )
#set( $P_LOCATION = $Add_Location_Permission )
#set( $P_STORAGE = $Add_Storage_Permission )
#set( $P_CONTACTS = $Add_Contacts_Permission )

#if( $P_CAMERA != "" || $P_NOTIFICATIONS != "" || $P_MICROPHONE != "" || $P_PHONE != "" || $P_LOCATION != "" || $P_STORAGE != "" || $P_CONTACTS != "")
import android.Manifest
import #parse("RootPkg.kt").R
#end
import androidx.annotation.StringRes

sealed interface AppPermission {
    @get:StringRes val rationaleTitle: Int
    @get:StringRes val rationaleMessage: Int
}

sealed class SinglePermission(
    val permission: String,
    override val rationaleTitle: Int,
    override val rationaleMessage: Int
) : AppPermission

sealed class MultiPermission(
    val permissions: Array<String>,
    override val rationaleTitle: Int,
    override val rationaleMessage: Int
) : AppPermission

#if( $P_CAMERA != "")
object CameraPermission : SinglePermission(
    permission = Manifest.permission.CAMERA,
    rationaleTitle = R.string.title_camera_permission,
    rationaleMessage = R.string.msg_camera_permission
)
#end
#if( $P_NOTIFICATION != "")
object NotificationPermission: SinglePermission(
    permission = Manifest.permission.POST_NOTIFICATIONS,
    rationaleTitle = R.string.title_notification_permission,
    rationaleMessage = R.string.msg_notification_permission
)
#end
#if( $P_MICROPHONE != "")
object MicrophonePermission: SinglePermission(
    permission = Manifest.permission.RECORD_AUDIO,
    rationaleTitle = R.string.title_camera_permission,
    rationaleMessage = R.string.msg_camera_permission
)
#end
#if( $P_PHONE != "")
object PhonePermission: SinglePermission(
    permission = Manifest.permission.READ_PHONE_STATE,
    rationaleTitle = R.string.title_phone_permission,
    rationaleMessage = R.string.msg_phone_permission
)
#end
#if( $P_LOCATION != "")
object LocationPermission : MultiPermission(
    permissions = arrayOf(
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION
    ),
    rationaleTitle = R.string.title_location_permission,
    rationaleMessage = R.string.msg_location_permission
)
#end

#if( $P_STORAGE != "")
object StoragePermission : MultiPermission(
    permissions = arrayOf(
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.WRITE_EXTERNAL_STORAGE
    ),
    rationaleTitle = R.string.title_storage_permission,
    rationaleMessage = R.string.msg_storage_permission
)
#end
#if( $P_CONTACTS != "")
object ContactsPermission : MultiPermission(
    permissions = arrayOf(
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.WRITE_CONTACTS
    ),
    rationaleTitle = R.string.title_contacts_permission,
    rationaleMessage = R.string.msg_contacts_permission
)
#end